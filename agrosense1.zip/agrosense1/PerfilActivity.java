/**
 *
 *
 * Actividad que muestra el perfil del usuario, incluyendo su información personal
 * (como nombre, correo electrónico y foto de perfil) y permite interactuar con
 * diferentes funcionalidades de la aplicación mediante un menú lateral.
 * También detecta la conexión a una red Wi-Fi específica para dispositivos medidores
 * y ofrece opciones como cerrar sesión o navegar entre pantallas de la aplicación.
 */

package com.example.agrosense1;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONObject;

public class PerfilActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageButton btnMenu;
    private Button btnPerfil, btnPlantas, btnMapeo, btnHistorial, btnSalir, btnGrafica, btnLogout, btnGuardar;
    private TextView tvName, tvEmail, tvDevice;
    private ImageView ivProfilePicture;
    private FirebaseAuth firebaseAuth;
    private Spinner spinnerCodigoPais;
    private EditText etNumero;
    /**
     * Método que se ejecuta al crear la actividad.
     * Inicializa los elementos de la interfaz, configura los botones del menú,
     * carga los datos del usuario desde la base de datos y detecta la conexión Wi-Fi.
     *
     * @param savedInstanceState Estado previamente guardado de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // Inicializa FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance();

        // Referencias a los elementos del layout
        drawerLayout = findViewById(R.id.drawer_layout);
        btnMenu = findViewById(R.id.btnMenu);
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvDevice = findViewById(R.id.tvDevice);
        ivProfilePicture = findViewById(R.id.ivProfilePicture);
        btnLogout = findViewById(R.id.btnLogout);
        btnGuardar = findViewById(R.id.btnGuardar);
        spinnerCodigoPais = findViewById(R.id.spinnerCodigoPais);
        etNumero = findViewById(R.id.etNumero);

        // Referencias a los botones del menú
        btnPerfil = findViewById(R.id.btnPerfil);
        btnPlantas = findViewById(R.id.btnPlantas);
        btnMapeo = findViewById(R.id.btnMapeo);
        btnGrafica = findViewById(R.id.btnGrafica);
        btnHistorial = findViewById(R.id.btnHistorial);
        btnSalir = findViewById(R.id.btnSalir);


        // Configuración del Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.codigos_pais, R.layout.spinner_item_custom);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerCodigoPais.setAdapter(adapter);


        // Configuración de los botones
        setupMenuButtons();

        // Carga los datos del usuario desde la base de datos
        loadUserData();

        // Detecta si hay un dispositivo medidor conectado
        conecctwifi();

        // Guardar el número de teléfono
        btnGuardar.setOnClickListener(v -> guardarNumeroTelefono());
    }

    /**
     * Detecta si el dispositivo está conectado a la red ESP_47579D
     * y muestra el estado e IP en la interfaz.
     */
    private void conecctwifi() {
        String targetSSID = "ESP_47579D";  // Tu SSID

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm != null ? cm.getActiveNetworkInfo() : null;
        if (ni != null && ni.isConnected() && ni.getType() == ConnectivityManager.TYPE_WIFI) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm != null ? wm.getConnectionInfo() : null;
            if (wi != null) {
                // Android devuelve el SSID entre comillas, así que las removemos
                String currentSSID = wi.getSSID().replace("\"", "");
                String currentIP   = intToIp(wi.getIpAddress());

                if (currentSSID.equals(targetSSID)) {
                    Log.d("conecctwifi", "Conectado a " + currentSSID + " con IP " + currentIP);
                    tvDevice.setText("Conectado: " + currentIP);
                } else {
                    Log.d("conecctwifi", "Conectado a otra red (" + currentSSID + ")");
                    tvDevice.setText("Desconectado");
                }
                return;
            }
        }

        // No hay conexión Wi-Fi o no es la red esperada
        Log.d("conecctwifi", "No estás conectado a ninguna red WiFi válida.");
        tvDevice.setText("Desconectado");
    }

    /**
     * Convierte una IP en int (little-endian) a string legible.
     */
    private String intToIp(int ip) {
        return  (ip & 0xFF)       + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF)+ "." +
                ((ip >> 24) & 0xFF);
    }


    /**
     * Configura las acciones de los botones del menú lateral.
     * Incluye navegación entre actividades, cierre de sesión y control del menú.
     */
    private void setupMenuButtons() {
        btnMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(findViewById(R.id.menu_layout))) {
                drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
            } else {
                drawerLayout.openDrawer(findViewById(R.id.menu_layout));
            }
        });

        btnLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Cerrar sesión")
                    .setMessage("¿Estás seguro de que deseas cerrar sesión? Todos los datos locales serán eliminados.")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        // Cierra la sesión en FirebaseAuth
                        firebaseAuth.signOut();

                        // Elimina todos los datos de la base de datos local
                        DatabaseManager dbManager = new DatabaseManager(PerfilActivity.this);
                        dbManager.clearDatabase();
                        Log.d("Logout", "Base de datos limpiada correctamente.");

                        // Redirige al formulario de inicio de sesión
                        startActivity(new Intent(PerfilActivity.this, LoginFormActivity.class));

                        // Cierra todas las actividades
                        finishAffinity();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        btnPerfil.setOnClickListener(v -> drawerLayout.closeDrawer(findViewById(R.id.menu_layout)));

        btnPlantas.setOnClickListener(v -> {
            startActivity(new Intent(PerfilActivity.this, PlantActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnMapeo.setOnClickListener(v -> {
            startActivity(new Intent(PerfilActivity.this, HomeActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnGrafica.setOnClickListener(v -> {
            startActivity(new Intent(PerfilActivity.this, GraficaActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnHistorial.setOnClickListener(v -> {
            startActivity(new Intent(PerfilActivity.this, HistorialActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnSalir.setOnClickListener(v -> finishAffinity());
    }

    /**
     * Carga los datos del usuario almacenados en la base de datos local SQLite.
     *
     * Este método realiza lo siguiente:
     * 1. Obtiene una instancia de DatabaseManager para acceder a la base de datos.
     * 2. Consulta los datos del usuario almacenado, asumiendo que solo existe un usuario (primera fila).
     * 3. Recupera campos como nombre, correo, foto (en bytes) y número telefónico, verificando que existan las columnas.
     * 4. Actualiza los elementos visuales (TextView, ImageView, Spinner, EditText) con los datos recuperados.
     *    - Si no hay datos, muestra valores predeterminados (ej. "User99999" para nombre).
     * 5. Maneja la selección del código de país en el Spinner basándose en el número telefónico guardado.
     * 6. Cierra el cursor para liberar recursos.
     */
    private void loadUserData() {
        DatabaseManager dbManager = new DatabaseManager(this);
        //Cursor cursor = dbManager.getUsuarioById(1);  // Consulta por id=1
        Cursor cursor = dbManager.getUsuarioMasReciente();

        if (cursor != null && cursor.moveToFirst()) {
            int idxNombre = cursor.getColumnIndex("nombre");
            int idxCorreo = cursor.getColumnIndex("correo");
            int idxFoto = cursor.getColumnIndex("foto");
            int idxNumero = cursor.getColumnIndex("numero");

            String name = idxNombre != -1 ? cursor.getString(idxNombre) : null;
            String email = idxCorreo != -1 ? cursor.getString(idxCorreo) : null;
            byte[] photoBytes = idxFoto != -1 ? cursor.getBlob(idxFoto) : null;
            String numeroTelefono = idxNumero != -1 ? cursor.getString(idxNumero) : null;

            // Actualizar la interfaz con los datos
            tvName.setText(name != null ? name : "User99999");
            tvEmail.setText(email != null ? email : "Correo no disponible");

            if (photoBytes != null && photoBytes.length > 0) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.length);
                ivProfilePicture.setImageBitmap(bitmap);
            } else {
                ivProfilePicture.setImageResource(R.drawable.person);
            }

            if (numeroTelefono != null && !numeroTelefono.isEmpty()) {
                String[] splitNumero = numeroTelefono.split(" ", 2);
                if (splitNumero.length == 2) {
                    String codigoPais = splitNumero[0];
                    String numero = splitNumero[1];

                    // Seleccionar código país en el Spinner
                    for (int i = 0; i < spinnerCodigoPais.getCount(); i++) {
                        if (spinnerCodigoPais.getItemAtPosition(i).toString().startsWith(codigoPais)) {
                            spinnerCodigoPais.setSelection(i);
                            break;
                        }
                    }

                    etNumero.setText(numero);
                }
            } else {
                etNumero.setText("");
            }
        } else {
            // No existen datos de usuario; valores por defecto
            tvName.setText("User99999");
            tvEmail.setText("Correo no disponible");
            ivProfilePicture.setImageResource(R.drawable.person);
            etNumero.setText("");
        }

        if (cursor != null) {
            cursor.close();
        }
    }


    /**
     * Guarda o actualiza el número telefónico del usuario en la base de datos local SQLite.
     *
     * Flujo del método:
     * 1. Obtiene el código de país seleccionado en el Spinner y el número telefónico ingresado.
     * 2. Valida que el número telefónico no esté vacío y tenga al menos 10 dígitos.
     * 3. Consulta si ya existe al menos un usuario registrado en la base de datos:
     *    - Si existe, obtiene su ID y actualiza el campo "numero" de esa fila.
     *    - Si no existe, inserta una nueva fila con el número completo.
     * 4. Muestra un Toast para informar al usuario el resultado de la operación (éxito o fallo).
     * 5. Recarga los datos del usuario para refrescar la UI con la información actualizada.
     *
     * NOTA: Este método asume que la tabla tiene una columna "id" que identifica la fila de usuario.
     */
    private void guardarNumeroTelefono() {
        DatabaseManager dbManager = new DatabaseManager(this);

        String codigoPais = spinnerCodigoPais.getSelectedItem().toString().split(" ")[0];
        String numero = etNumero.getText().toString().trim();

        if (numero.isEmpty() || numero.length() < 10) {
            Toast.makeText(this, "Por favor, ingresa un número válido (al menos 10 dígitos).", Toast.LENGTH_SHORT).show();
            return;
        }

        String numeroCompleto = codigoPais + " " + numero;

        Cursor cursor = dbManager.getUsuarioMasReciente();

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndex("id")); // Obtiene el id del usuario más reciente
            boolean actualizado = dbManager.actualizarNumeroTelefono(userId, numeroCompleto);

            if (actualizado) {
                Toast.makeText(this, "Número actualizado correctamente.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error al actualizar el número.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Si no hay usuario registrado, inserta uno nuevo con solo el número
            boolean insertado = dbManager.insertarUsuarioConNumero(numeroCompleto);
            if (insertado) {
                Toast.makeText(this, "Número guardado correctamente.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error al guardar el número.", Toast.LENGTH_SHORT).show();
            }
        }

        if (cursor != null) cursor.close();

        loadUserData();
    }
}