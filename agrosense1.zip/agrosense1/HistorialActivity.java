package com.example.agrosense1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * HistorialActivity
 *
 * Clase que gestiona la pantalla de historial de mediciones en la app AgroSense.
 * Muestra una lista de mediciones almacenadas y permite la navegación a otras actividades.
 * También permite generar un reporte PDF personalizado y enviarlo por WhatsApp.
 */
public class HistorialActivity extends AppCompatActivity {

    // Layout y controles UI principales
    private DrawerLayout drawerLayout;    // Layout del menú lateral
    private ImageButton btnMenu, btnDescarga; // Botones para menú y descarga
    private RecyclerView recyclerView;    // Lista de mediciones
    private MedicionesAdapter adapter;    // Adaptador para RecyclerView
    private List<Medicion> listaMediciones;  // Datos de mediciones

    // Botones del menú lateral para navegar a otras actividades
    private Button btnPerfil, btnPlantas, btnMapeo, btnHistorial, btnSalir, btnGrafica;

    /**
     * Método onCreate se ejecuta al iniciar la actividad.
     * Aquí se inicializan los elementos UI, configura RecyclerView, carga datos
     * y se configuran los eventos de botones y menú lateral.
     *
     * @param savedInstanceState Estado previo de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        // Referencias a elementos del layout
        drawerLayout = findViewById(R.id.drawer_layout);
        btnMenu = findViewById(R.id.btnMenu);
        btnDescarga = findViewById(R.id.btnDescarga);

        btnPerfil = findViewById(R.id.btnPerfil);
        btnPlantas = findViewById(R.id.btnPlantas);
        btnMapeo = findViewById(R.id.btnMapeo);
        btnGrafica = findViewById(R.id.btnGrafica);
        btnHistorial = findViewById(R.id.btnHistorial);
        btnSalir = findViewById(R.id.btnSalir);

        recyclerView = findViewById(R.id.recyclerView);
        listaMediciones = new ArrayList<>();
        adapter = new MedicionesAdapter(listaMediciones);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Carga datos desde la base SQLite
        loadData();

        // Evento para abrir o cerrar el menú lateral
        btnMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(findViewById(R.id.menu_layout))) {
                drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
            } else {
                drawerLayout.openDrawer(findViewById(R.id.menu_layout));
            }
        });

        // Navegación menú lateral
        btnPerfil.setOnClickListener(v -> {
            startActivity(new Intent(HistorialActivity.this, PerfilActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnPlantas.setOnClickListener(v -> {
            startActivity(new Intent(HistorialActivity.this, PlantActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnMapeo.setOnClickListener(v -> {
            startActivity(new Intent(HistorialActivity.this, HomeActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnGrafica.setOnClickListener(v -> {
            startActivity(new Intent(HistorialActivity.this, GraficaActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnHistorial.setOnClickListener(v -> {
            startActivity(new Intent(HistorialActivity.this, HistorialActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnSalir.setOnClickListener(v -> finishAffinity());

        // Evento botón para generar y enviar PDF por WhatsApp
        btnDescarga.setOnClickListener(v -> {
            // Copia la plantilla PDF desde res/raw a almacenamiento externo privado si no existe
            copyPdfFromRawToExternal();

            DatabaseManager dbManager = new DatabaseManager(this);

            Cursor cursor = dbManager.getUsuarios();
            final String numeroAsociado;
            final String usuarioNombre;

            if (cursor != null && cursor.moveToFirst()) {
                int colIndexNumero = cursor.getColumnIndex("numero");
                int colIndexNombre = cursor.getColumnIndex("nombre"); // Ajusta si tu columna tiene otro nombre

                if (colIndexNumero != -1) {
                    numeroAsociado = cursor.getString(colIndexNumero);
                } else {
                    Log.e("HistorialActivity", "Columna 'numero' no encontrada en el cursor");
                    numeroAsociado = null;
                }

                if (colIndexNombre != -1) {
                    usuarioNombre = cursor.getString(colIndexNombre);
                } else {
                    usuarioNombre = "Usuario Desconocido";
                }

                cursor.close();
            } else {
                numeroAsociado = null;
                usuarioNombre = "Usuario Desconocido";
            }

            if (numeroAsociado == null || numeroAsociado.trim().isEmpty()) {
                new AlertDialog.Builder(this)
                        .setTitle("Número no asociado")
                        .setMessage("No se ha asociado ningún número a la app AgroSense. Primero ingresa un número.")
                        .setCancelable(false)
                        .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss())
                        .setPositiveButton("Actualizar número", (dialog, which) -> {
                            startActivity(new Intent(this, PerfilActivity.class));
                            dialog.dismiss();
                        })
                        .show();
                return;
            }

            // Obtener planta cargada y sus datos esperados
            DatabaseManager.PlantaData plantaData = dbManager.getPlantaCargada();

            Cursor cursorMed = dbManager.getMediciones();

            final String fechaMedicion;
            final String plantaNombre;
            final String medicionDesc = "Última medición";
            final String fechaActual = getCurrentDateTime();

            final String nitrogenoResultado;
            final String fosforoResultado;
            final String potacioResultado;
            final String humedadResultado;
            final String humedadUnidad = "%";
            final String conductividadResultado;
            final String conductividadUnidad = "dS/m";
            final String phResultado;
            final String phUnidad = "pH";

            if (cursorMed != null && cursorMed.moveToLast()) {
                fechaMedicion = cursorMed.getString(cursorMed.getColumnIndex(DatabaseManager.FECHA_HORA));
                nitrogenoResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.NITROGENO)));
                fosforoResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.FOSFORO)));
                potacioResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.POTASIO)));
                humedadResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.HUMEDAD)));
                conductividadResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.CONDUCTIVIDAD)));
                phResultado = String.valueOf(cursorMed.getFloat(cursorMed.getColumnIndex(DatabaseManager.PH)));
                plantaNombre = plantaData != null ? plantaData.nombre : "Planta";
                cursorMed.close();
            } else {
                fechaMedicion = "";
                plantaNombre = "Planta";
                nitrogenoResultado = "";
                fosforoResultado = "";
                potacioResultado = "";
                humedadResultado = "";
                conductividadResultado = "";
                phResultado = "";
            }

            new AlertDialog.Builder(this)
                    .setTitle("Número asociado")
                    .setMessage("Número registrado: " + numeroAsociado)
                    .setCancelable(true)
                    .setNegativeButton("Actualizar", (dialog, which) -> {
                        startActivity(new Intent(this, PerfilActivity.class));
                        dialog.dismiss();
                    })
                    .setPositiveButton("Enviar por WhatsApp", (dialog, which) -> {
                        dialog.dismiss();
                        try {
                            File pdfLleno = llenarPdfConIText(
                                    usuarioNombre,
                                    numeroAsociado,
                                    fechaActual,
                                    medicionDesc,
                                    fechaMedicion,
                                    plantaNombre,
                                    nitrogenoResultado, "mg/kg", String.valueOf(plantaData != null ? plantaData.nitrogeno : ""),
                                    fosforoResultado, "mg/kg", String.valueOf(plantaData != null ? plantaData.fosforo : ""),
                                    potacioResultado, "mg/kg", String.valueOf(plantaData != null ? plantaData.potasio : ""),
                                    humedadResultado, humedadUnidad,
                                    conductividadResultado, conductividadUnidad,
                                    phResultado, phUnidad
                            );

                            enviarPdfPorWhatsapp(pdfLleno, numeroAsociado);

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(this, "Error generando PDF con datos dinámicos.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        });



    }

    /**
     * Método onResume que se ejecuta cuando la actividad vuelve al frente.
     * Aquí se elimina el PDF temporal generado para no saturar almacenamiento.
     */
    @Override
    protected void onResume() {
        super.onResume();
        File pdfFile = new File(getExternalFilesDir("media/agrosense"), "reporte_agrosense_lleno.pdf");
        if (pdfFile.exists()) {
            boolean deleted = pdfFile.delete();
            Log.i("DeletePDF", "Archivo PDF eliminado en onResume(): " + deleted);
        }
    }

    /**
     * Envía el archivo PDF especificado por WhatsApp al número proporcionado.
     *
     * @param pdfFile      Archivo PDF que se enviará.
     * @param numeroCompleto Número telefónico asociado para envío.
     */
    private void enviarPdfPorWhatsapp(File pdfFile, String numeroCompleto) {
        try {
            if (!pdfFile.exists()) {
                Toast.makeText(this, "El archivo PDF no fue encontrado.", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri pdfUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", pdfFile);
            String numeroLimpio = numeroCompleto.replaceAll("[^\\d]", "");

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, pdfUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            String packageName = "com.whatsapp";
            try {
                getPackageManager().getPackageInfo(packageName, 0);
            } catch (Exception e) {
                packageName = "com.whatsapp.w4b";
                try {
                    getPackageManager().getPackageInfo(packageName, 0);
                } catch (Exception ex) {
                    packageName = null;
                }
            }

            if (packageName != null) {
                intent.setPackage(packageName);
            }

            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(intent, "Enviar PDF vía"));
            } else {
                Toast.makeText(this, "WhatsApp no está instalado o no puede manejar el archivo.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error enviando PDF por WhatsApp.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Copia el archivo PDF plantilla desde recursos raw al almacenamiento privado externo.
     * Evita sobrescribir si ya existe.
     */
    void copyPdfFromRawToExternal() {
        File targetDir = new File(getExternalFilesDir(null), "media/agrosense");
        if (!targetDir.exists() && !targetDir.mkdirs()) {
            Log.e("CopyPDF", "No se pudo crear el directorio: " + targetDir.getAbsolutePath());
            return;
        }
        File targetFile = new File(targetDir, "reporte_agrosense.pdf");
        if (targetFile.exists()) return;
        try (InputStream in = getResources().openRawResource(R.raw.reporte_agrosense);
             OutputStream out = new FileOutputStream(targetFile)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            Log.i("CopyPDF", "Archivo PDF copiado exitosamente en: " + targetFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("CopyPDF", "Error al copiar archivo PDF: " + e.getMessage());
        }
    }

    /**
     * Llena la plantilla PDF con los datos proporcionados y guarda un nuevo archivo PDF.
     *
     * @param usuario              Nombre del usuario.
     * @param telefono             Número telefónico.
     * @param fechaActual          Fecha actual.
     * @param medicion             Descripción de la medición.
     * @param fechaMedicion        Fecha de la medición.
     * @param planta               Nombre de la planta.
     * @param nitrogenoResultado   Resultado nitrógeno.
     * @param nitrogenoUnidad      Unidad nitrógeno.
     * @param nitrogenoEsperado    Valor esperado nitrógeno.
     * @param fosforoResultado     Resultado fósforo.
     * @param fosforoUnidad        Unidad fósforo.
     * @param fosforoEsperado      Valor esperado fósforo.
     * @param potacioResultado     Resultado potasio.
     * @param potacioUnidad        Unidad potasio.
     * @param potacioEsperado      Valor esperado potasio.
     * @param humedadResultado     Resultado humedad.
     * @param humedadUnidad        Unidad humedad.
     * @param conductividadResultado Resultado conductividad.
     * @param conductividadUnidad  Unidad conductividad.
     * @param phResultado          Resultado pH.
     * @param phUnidad             Unidad pH.
     * @return Archivo PDF generado con datos llenados.
     * @throws Exception En caso de error al manipular el PDF.
     */
    public File llenarPdfConIText(
            String usuario,
            String telefono,
            String fechaActual,
            String medicion,
            String fechaMedicion,
            String planta,
            String nitrogenoResultado,
            String nitrogenoUnidad,
            String nitrogenoEsperado,
            String fosforoResultado,
            String fosforoUnidad,
            String fosforoEsperado,
            String potacioResultado,
            String potacioUnidad,
            String potacioEsperado,
            String humedadResultado,
            String humedadUnidad,
            String conductividadResultado,
            String conductividadUnidad,
            String phResultado,
            String phUnidad
    ) throws Exception {
        String inputPath = new File(getExternalFilesDir("media/agrosense"), "reporte_agrosense.pdf").getAbsolutePath();
        String outputPath = new File(getExternalFilesDir("media/agrosense"), "reporte_agrosense_lleno.pdf").getAbsolutePath();

        PdfReader reader = new PdfReader(inputPath);
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(outputPath));

        BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
        PdfContentByte canvas = stamper.getOverContent(1);

        canvas.beginText();
        canvas.setFontAndSize(bf, 10);

        canvas.setTextMatrix(241, 625);  // Usuario
        canvas.showText(usuario);

        canvas.setTextMatrix(260, 612);  // Teléfono
        canvas.showText(telefono);

        canvas.setTextMatrix(260, 582);  // Fecha actual
        canvas.showText(fechaActual);

        canvas.setTextMatrix(475, 625);  // Fecha de medición
        canvas.showText(fechaMedicion);

        canvas.setTextMatrix(260, 568);  // Medición
        canvas.showText(medicion);

        canvas.setTextMatrix(475, 598);  // Planta
        canvas.showText(planta);

        float baseX = 200;
        float baseY = 450;
        float rowHeight = 40;

        canvas.setTextMatrix(baseX, baseY);
        canvas.showText(nitrogenoResultado);
        canvas.setTextMatrix(baseX + 120, baseY);
        canvas.showText(nitrogenoUnidad);
        canvas.setTextMatrix(baseX + 270, baseY);
        canvas.showText(nitrogenoEsperado);

        canvas.setTextMatrix(baseX, baseY - rowHeight);
        canvas.showText(fosforoResultado);
        canvas.setTextMatrix(baseX + 122, baseY - rowHeight);
        canvas.showText(fosforoUnidad);
        canvas.setTextMatrix(baseX + 270, baseY - rowHeight);
        canvas.showText(fosforoEsperado);

        canvas.setTextMatrix(baseX, baseY - 2 * rowHeight);
        canvas.showText(potacioResultado);
        canvas.setTextMatrix(baseX + 122, baseY - 2 * rowHeight);
        canvas.showText(potacioUnidad);
        canvas.setTextMatrix(baseX + 270, baseY - 2 * rowHeight);
        canvas.showText(potacioEsperado);

        canvas.setTextMatrix(baseX, baseY - 3 * rowHeight);
        canvas.showText(humedadResultado);
        canvas.setTextMatrix(baseX + 122, baseY - 3 * rowHeight);
        canvas.showText(humedadUnidad);

        canvas.setTextMatrix(baseX, baseY - 4 * rowHeight);
        canvas.showText(conductividadResultado);
        canvas.setTextMatrix(baseX + 122, baseY - 4 * rowHeight);
        canvas.showText(conductividadUnidad);

        canvas.setTextMatrix(baseX, baseY - 5 * rowHeight);
        canvas.showText(phResultado);
        canvas.setTextMatrix(baseX + 122, baseY - 5 * rowHeight);
        canvas.showText(phUnidad);

        canvas.endText();

        stamper.close();
        reader.close();

        return new File(outputPath);
    }

    /**
     * Carga las mediciones almacenadas en la base de datos y actualiza la lista mostrada en pantalla.
     */
    private void loadData() {
        DatabaseManager dbManager = new DatabaseManager(this);
        Cursor cursor = dbManager.getMediciones();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                float humedad = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.HUMEDAD));
                float conductividad = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.CONDUCTIVIDAD));
                float ph = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.PH));
                float nitrogeno = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.NITROGENO));
                float fosforo = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.FOSFORO));
                float potasio = cursor.getFloat(cursor.getColumnIndex(DatabaseManager.POTASIO));
                String fechaHora = cursor.getString(cursor.getColumnIndex(DatabaseManager.FECHA_HORA));
                String planta = cursor.getString(cursor.getColumnIndex(DatabaseManager.PLANTA));

                Medicion medicion = new Medicion(humedad, conductividad, ph, nitrogeno, fosforo, potasio, fechaHora, planta);
                listaMediciones.add(medicion);
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }

    public String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date now = new Date();
        return sdf.format(now);
    }
}
