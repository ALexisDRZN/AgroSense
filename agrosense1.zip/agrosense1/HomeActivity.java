/**
 * HomeActivity
 *
 * Clase que gestiona la actividad principal de la aplicación AgroSense, enfocada en la visualización
 * de mapas utilizando Google Maps. Incluye la funcionalidad de:
 * - Mostrar marcadores en el mapa.
 * - Dibujar polígonos en áreas específicas.
 * - Gestionar ubicaciones del usuario.
 * - Sincronizar datos desde un servidor remoto.
 */

package com.example.agrosense1;

// Importaciones estáticas
import static android.content.ContentValues.TAG; // Para registrar etiquetas en los logs.

// Permisos y gestión de la aplicación
import android.Manifest; // Permiso para acceder a la ubicación del dispositivo.
import android.content.Intent; // Permite la navegación entre actividades.
import android.content.pm.PackageManager; // Gestiona permisos otorgados por el usuario.
import android.graphics.Color; // Utilizado para colores en polígonos y líneas.
import android.util.Log; // Permite registrar mensajes para depuración.
import android.widget.Button; // Botón interactivo en la interfaz de usuario.
import android.widget.ImageButton; // Botón de imagen interactivo en la interfaz de usuario.
import android.widget.Toast; // Mensajes emergentes breves para el usuario.

// AndroidX
import androidx.annotation.NonNull; // Anotación para especificar que un valor no puede ser nulo.
import androidx.appcompat.app.AppCompatActivity; // Clase base para actividades con soporte AppCompat.
import androidx.core.app.ActivityCompat; // Clase para manejar permisos en tiempo de ejecución.
import androidx.drawerlayout.widget.DrawerLayout; // Diseño para manejar un menú lateral (drawer).

// Gestión de estado
import android.os.Bundle; // Contiene datos de estado de la actividad.

// Librerías Volley para solicitudes HTTP
import com.android.volley.Request; // Representa un tipo de solicitud HTTP.
import com.android.volley.RequestQueue; // Cola para manejar solicitudes HTTP.
import com.android.volley.toolbox.StringRequest; // Solicitud HTTP para obtener datos como texto.
import com.android.volley.toolbox.Volley; // Biblioteca para manejar solicitudes HTTP.

// Google Maps API
import com.google.android.gms.location.FusedLocationProviderClient; // Cliente para acceder a la ubicación del dispositivo.
import com.google.android.gms.location.LocationServices; // Servicios de ubicación proporcionados por Google.
import com.google.android.gms.maps.CameraUpdateFactory; // Maneja actualizaciones de la cámara en Google Maps.
import com.google.android.gms.maps.GoogleMap; // Representa el mapa de Google.
import com.google.android.gms.maps.OnMapReadyCallback; // Interfaz para manejar el evento cuando el mapa está listo.
import com.google.android.gms.maps.SupportMapFragment; // Fragmento que contiene el mapa.
import com.google.android.gms.maps.model.LatLng; // Representa coordenadas en el mapa.
import com.google.android.gms.maps.model.LatLngBounds; // Representa límites geográficos en el mapa.
import com.google.android.gms.maps.model.Marker; // Representa un marcador en el mapa.
import com.google.android.gms.maps.model.MarkerOptions; // Opciones para configurar un marcador.
import com.google.android.gms.maps.model.Polygon; // Representa un polígono en el mapa.
import com.google.android.gms.maps.model.PolygonOptions; // Opciones para configurar un polígono.
import com.google.android.gms.maps.model.PolylineOptions; // Opciones para configurar una línea.

// Google Maps Utility Library
import com.google.maps.android.PolyUtil; // Clase para manejar operaciones geométricas como polígonos.

// Librerías estándar
import java.util.ArrayList; // Permite manejar listas dinámicas.
import java.util.List; // Interfaz para listas.

// SQLite para almacenamiento local
import android.database.Cursor; // Representa resultados de consultas a la base de datos.
import android.database.sqlite.SQLiteDatabase; // Clase principal para interactuar con SQLite.
/**
 * HomeActivity
 *
 * Clase que extiende `AppCompatActivity` e implementa la interfaz `OnMapReadyCallback`
 * para gestionar la actividad principal de la aplicación AgroSense. Proporciona:
 * - Un menú lateral para la navegación entre diferentes actividades.
 * - Funcionalidad de visualización y manipulación de mapas utilizando Google Maps.
 * - Gestión de marcadores y polígonos en el mapa.
 */
public class HomeActivity extends AppCompatActivity implements OnMapReadyCallback {

    // Variables para el menú
    private DrawerLayout drawerLayout;
    private ImageButton btnMenu;
    private Button btnPerfil, btnPlantas, btnMapeo, btnHistorial, btnSalir, btnGrafica;

    // Variables para el mapa
    private GoogleMap mMap;
    private ImageButton btnUbicacion;
    private Button btnCalcular, btnLimpiar, btnDescargarArea;
    private List<Marker> markers = new ArrayList<>();
    private Polygon polygon;
    private FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    /**
     * Método `onCreate`: Inicialización de la actividad Home.
     *
     * Configura el menú lateral, el mapa y los botones de acción, estableciendo sus respectivos
     * listeners. Los botones permiten limpiar el mapa, descargar un área seleccionada y generar un
     * cuadriculado dentro de un polígono dibujado en el mapa.
     *
     * @param savedInstanceState Estado previamente guardado de la actividad (si existe).
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Configuración del menú lateral
        configurarMenu();

        // Configuración del mapa
        configurarMapa();

        // Inicialización del cliente de ubicación
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // Configuración del botón "Limpiar"
        btnLimpiar = findViewById(R.id.btnLimpiar);
        btnLimpiar.setOnClickListener(v -> limpiarMapa());

        // Configuración del botón "Descargar Área"
        btnDescargarArea = findViewById(R.id.btnDescargarArea);
        btnDescargarArea.setOnClickListener(v -> descargarAreaSeleccionada());

        // Configuración del botón "Calcular"
        btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(v -> cuadricularPoligono());
    }

    /**
     * Método `cuadricularPoligono`: Genera un cuadriculado dentro del área definida por un polígono.
     *
     * Este método calcula el área del polígono en metros cuadrados y hectáreas, define un tamaño
     * adecuado para la cuadricula en función del área y genera un grid (rejilla) de líneas dentro
     * del polígono. Los bordes de las celdas están representados por líneas grises.
     */
    private void cuadricularPoligono() {
        if (polygon == null) {
            Toast.makeText(this, "No hay un área definida para cuadricular.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Calcular el área del polígono en metros cuadrados
        double areaEnMetrosCuadrados = calcularAreaDelPoligono(polygon.getPoints());
        Log.d("HomeActivity", "Área calculada: " + areaEnMetrosCuadrados + " m²");

        // Convertir el área a hectáreas
        double areaEnHectareas = areaEnMetrosCuadrados / 10000; // 1 hectárea = 10,000 m²
        Log.d("HomeActivity", "Área en hectáreas: " + areaEnHectareas);

        // Determinar el tamaño del cuadriculado en metros
        int tamanoCuadricula = 20 + (int) Math.floor(areaEnHectareas - 1) * 20;
        tamanoCuadricula = Math.max(tamanoCuadricula, 20); // Mínimo de 20x20 metros
        Log.d("HomeActivity", "Tamaño del cuadriculado: " + tamanoCuadricula + " metros");

        // Obtener límites del polígono (bounding box)
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng point : polygon.getPoints()) {
            boundsBuilder.include(point);
        }
        LatLngBounds bounds = boundsBuilder.build();

        // Coordenadas mínimas y máximas
        double minLat = bounds.southwest.latitude;
        double maxLat = bounds.northeast.latitude;
        double minLng = bounds.southwest.longitude;
        double maxLng = bounds.northeast.longitude;

        // Generar el cuadriculado dentro del área
        for (double lat = minLat; lat <= maxLat; lat += tamanoCuadricula / 111320.0) { // 1 grado de latitud ~ 111.32 km
            for (double lng = minLng; lng <= maxLng; lng += tamanoCuadricula / (111320.0 * Math.cos(Math.toRadians(lat)))) {
                // Verificar si el punto está dentro del polígono
                LatLng punto = new LatLng(lat, lng);
                if (PolyUtil.containsLocation(punto, polygon.getPoints(), true)) {
                    // Dibujar los bordes de la celda
                    LatLng topRight = new LatLng(lat, lng + tamanoCuadricula / (111320.0 * Math.cos(Math.toRadians(lat))));
                    LatLng bottomLeft = new LatLng(lat - tamanoCuadricula / 111320.0, lng);

                    // Dibujar líneas horizontales y verticales
                    mMap.addPolyline(new PolylineOptions()
                            .add(punto, topRight)
                            .color(Color.GRAY)
                            .width(2));
                    mMap.addPolyline(new PolylineOptions()
                            .add(punto, bottomLeft)
                            .color(Color.GRAY)
                            .width(2));
                }
            }
        }

        Toast.makeText(this, "Cuadriculado generado dentro del polígono.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Método para calcular el área de un polígono.
     *
     * Este método utiliza la fórmula del área del polígono en coordenadas geográficas, también conocida como fórmula del área de un polígono simple.
     * Calcula el área en grados cuadrados y luego convierte el resultado a metros cuadrados utilizando un factor aproximado.
     *
     * @param puntos Una lista de objetos `LatLng` que representan los vértices del polígono (en orden).
     * @return El área del polígono en metros cuadrados.
     */
    private double calcularAreaDelPoligono(List<LatLng> puntos) {
        double area = 0.0;
        int n = puntos.size(); // Número de vértices del polígono.

        // Iterar sobre cada par de puntos consecutivos en el polígono.
        for (int i = 0; i < n; i++) {
            LatLng punto1 = puntos.get(i);
            LatLng punto2 = puntos.get((i + 1) % n); // Usar módulo para conectar el último punto con el primero.

            // Calcular el determinante parcial y acumularlo en el área.
            area += punto1.longitude * punto2.latitude - punto2.longitude * punto1.latitude;
        }

        // Tomar el valor absoluto y dividir entre 2 para obtener el área en grados cuadrados.
        area = Math.abs(area) / 2.0;

        // Convertir el área de grados cuadrados a metros cuadrados usando un factor aproximado.
        return area * 12365.161; // Factor de conversión aproximado para áreas en coordenadas geográficas.
    }
    /**
     * Método `configurarMenu`: Configura el menú lateral de navegación.
     *
     * Este método inicializa los componentes del menú lateral, como el `DrawerLayout` y los botones,
     * y define sus comportamientos. Permite al usuario abrir/cerrar el menú, así como navegar entre
     * diferentes actividades de la aplicación.
     */
    private void configurarMenu() {
        // Inicialización del DrawerLayout y del botón del menú
        drawerLayout = findViewById(R.id.drawer_layout);
        btnMenu = findViewById(R.id.btnMenu);

        // Inicialización de los botones del menú lateral
        btnPerfil = findViewById(R.id.btnPerfil);
        //btnPerfil.setBackgroundResource(R.drawable.button_background);
        btnPlantas = findViewById(R.id.btnPlantas);
        //btnPlantas.setBackgroundResource(R.drawable.button_background);
        btnMapeo = findViewById(R.id.btnMapeo);
        //btnMapeo.setBackgroundResource(R.drawable.button_background);
        btnGrafica = findViewById(R.id.btnGrafica);
        //btnGrafica.setBackgroundResource(R.drawable.button_background);
        btnHistorial = findViewById(R.id.btnHistorial);
        //btnHistorial.setBackgroundResource(R.drawable.button_background);
        btnSalir = findViewById(R.id.btnSalir);
        //btnSalir.setBackgroundResource(R.drawable.button_background);

        // Configuración del botón para abrir/cerrar el menú lateral
        btnMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(findViewById(R.id.menu_layout))) {
                drawerLayout.closeDrawer(findViewById(R.id.menu_layout)); // Cierra el menú si está abierto
            } else {
                drawerLayout.openDrawer(findViewById(R.id.menu_layout)); // Abre el menú si está cerrado
            }
        });

        // Configuración de los botones para navegar entre actividades
        btnPerfil.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, PerfilActivity.class))); // Ir a Perfil
        btnPlantas.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, PlantActivity.class))); // Ir a Plantas
        btnMapeo.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, HomeActivity.class))); // Ir a Mapeo
        btnGrafica.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, GraficaActivity.class))); // Ir a Gráfica
        btnHistorial.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, HistorialActivity.class))); // Ir a Historial
        btnSalir.setOnClickListener(v -> finishAffinity()); // Cierra la aplicación
    }

    /**
     * Método `configurarMapa`: Configura el mapa y los botones relacionados.
     *
     * Este método inicializa los componentes relacionados con el mapa y los botones de acción
     * asociados. Configura el fragmento del mapa, agrega un listener para obtener el mapa
     * asincrónicamente y define acciones para los botones "Ubicación" y "Calcular".
     */
    private void configurarMapa() {
        // Inicialización de botones relacionados con el mapa
        btnUbicacion = findViewById(R.id.btnUbicacion); // Botón para centrar en la ubicación actual.
        btnCalcular = findViewById(R.id.btnCalcular);   // Botón para calcular el perímetro.

        // Configuración del fragmento del mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this); // Configura el mapa para ser manejado asincrónicamente.
        }

        // Acción del botón "Ubicación"
        btnUbicacion.setOnClickListener(v -> centrarEnUbicacionActual());

        // Acción del botón "Calcular"
        btnCalcular.setOnClickListener(v -> calcularPerimetro());
    }
    /**
     * Método `onMapReady`: Configuración inicial del mapa.
     *
     * Este método se ejecuta cuando el mapa está listo para ser usado. Configura el tipo de mapa,
     * verifica si hay áreas guardadas en la base de datos y, si no las hay, permite al usuario agregar
     * manualmente puntos en el mapa para formar un área rectangular con marcadores.
     *
     * @param googleMap Instancia de `GoogleMap` lista para ser usada.
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        // Asignar el mapa a la variable global
        mMap = googleMap;

        // Configurar el tipo de mapa como satelital
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        // Verificar si hay áreas guardadas en la base de datos
        if (!cargarAreaGuardada()) {
            // Si no hay áreas guardadas, configurar el mapa para agregar puntos manualmente
            mMap.setOnMapClickListener(latLng -> {
                if (markers.size() < 4) {
                    // Agregar un marcador en la posición seleccionada
                    Marker marker = mMap.addMarker(new MarkerOptions().position(latLng));
                    markers.add(marker);

                    // Comprobar si ya se colocaron 4 marcadores y cerrar el rectángulo
                    if (markers.size() == 4) {
                        cerrarRectangulo();
                    }
                } else {
                    // Mostrar mensaje si ya hay 4 marcadores colocados
                    Toast.makeText(this, "Ya has colocado los 4 marcadores", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    /**
     * Método `cargarAreaGuardada`: Carga el área guardada desde la base de datos.
     *
     * Este método consulta la tabla `areas` en la base de datos para recuperar los límites de un área
     * previamente guardada. Si se encuentra un área, se dibuja un polígono en el mapa y la cámara
     * se centra en el área. Si no hay áreas guardadas, se notifica al usuario.
     *
     * @return `true` si se encontró y cargó un área guardada, `false` en caso contrario o si ocurre un error.
     */
    private boolean cargarAreaGuardada() {
        DatabaseManager dbManager = new DatabaseManager(this); // Instancia del administrador de la base de datos.
        SQLiteDatabase db = dbManager.getReadableDatabase();   // Base de datos en modo lectura.
        Cursor cursor = null;

        try {
            Log.d(TAG, "cargarAreaGuardada: Consultando la tabla 'areas'");
            // Consultar la tabla 'areas' para obtener los límites del área guardada
            cursor = db.query("areas", new String[]{"lat_min", "lng_min", "lat_max", "lng_max"},
                    null, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                Log.d(TAG, "cargarAreaGuardada: Se encontró al menos un área guardada");

                // Recuperar los límites del área desde el cursor
                double latMin = cursor.getDouble(cursor.getColumnIndex("lat_min"));
                double lngMin = cursor.getDouble(cursor.getColumnIndex("lng_min"));
                double latMax = cursor.getDouble(cursor.getColumnIndex("lat_max"));
                double lngMax = cursor.getDouble(cursor.getColumnIndex("lng_max"));

                Log.d(TAG, "cargarAreaGuardada: Datos del área -> latMin: " + latMin +
                        ", lngMin: " + lngMin + ", latMax: " + latMax + ", lngMax: " + lngMax);

                // Crear un polígono basado en los límites recuperados
                PolygonOptions rectOptions = new PolygonOptions()
                        .add(new LatLng(latMin, lngMin),
                                new LatLng(latMin, lngMax),
                                new LatLng(latMax, lngMax),
                                new LatLng(latMax, lngMin))
                        .strokeColor(Color.BLUE) // Color del borde del polígono
                        .fillColor(Color.argb(50, 0, 0, 255)); // Color de relleno del polígono con transparencia

                // Dibujar el polígono en el mapa
                polygon = mMap.addPolygon(rectOptions);

                // Calcular el centro del área y centrar la cámara en él
                LatLng center = new LatLng((latMin + latMax) / 2, (lngMin + lngMax) / 2);
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(center, 15));

                return true;
            } else {
                Log.d(TAG, "cargarAreaGuardada: La tabla 'areas' está vacía");
                Toast.makeText(this, "No se encontraron áreas guardadas.", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (Exception e) {
            Log.e(TAG, "cargarAreaGuardada: Error al acceder a la base de datos", e);
            Toast.makeText(this, "Error al cargar el área guardada: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        } finally {
            if (cursor != null) {
                cursor.close(); // Cerrar el cursor para liberar recursos
                Log.d(TAG, "cargarAreaGuardada: Cursor cerrado");
            }
        }
    }

    /**
     * Método `cerrarRectangulo`: Cierra un área rectangular en el mapa.
     *
     * Este método se ejecuta cuando se han colocado exactamente 4 marcadores en el mapa.
     * Utiliza las posiciones de estos marcadores para generar un polígono rectangular.
     * El polígono se renderiza en el mapa con un borde azul y un relleno semitransparente.
     */
    private void cerrarRectangulo() {
        if (markers.size() == 4) {
            // Crear una lista de puntos a partir de los marcadores
            List<LatLng> puntosRectangulo = new ArrayList<>();
            for (Marker m : markers) {
                puntosRectangulo.add(m.getPosition());
            }

            // Dibujar el polígono en el mapa
            polygon = mMap.addPolygon(new PolygonOptions()
                    .addAll(puntosRectangulo)
                    .strokeColor(Color.BLUE) // Color del borde del polígono
                    .fillColor(Color.argb(50, 0, 0, 255))); // Color del relleno con transparencia
        }
    }

    /**
     * Método `limpiarMapa`: Limpia el mapa y elimina datos guardados.
     *
     * Este método elimina todos los marcadores y el polígono del mapa, limpia la lista de marcadores
     * y elimina todas las áreas guardadas en la tabla "areas" de la base de datos. También configura
     * nuevamente el mapa para que el usuario pueda agregar puntos manualmente.
     */
    private void limpiarMapa() {
        // Limpiar marcadores del mapa
        for (Marker marker : markers) {
            marker.remove(); // Eliminar el marcador del mapa
        }
        markers.clear(); // Vaciar la lista de marcadores

        // Limpiar el polígono del mapa
        if (polygon != null) {
            polygon.remove(); // Eliminar el polígono del mapa
            polygon = null;   // Reiniciar la referencia al polígono
        }

        // Eliminar áreas guardadas en la base de datos
        DatabaseManager dbManager = new DatabaseManager(this);
        SQLiteDatabase db = dbManager.getWritableDatabase();
        int rowsDeleted = db.delete("areas", null, null); // Elimina todas las filas de la tabla "areas"
        Log.d(TAG, "limpiarMapa: Áreas eliminadas de la base de datos: " + rowsDeleted);

        // Configurar nuevamente el mapa para permitir la colocación de nuevos puntos
        if (mMap != null) {
            mMap.setOnMapClickListener(latLng -> {
                if (markers.size() < 4) {
                    // Agregar un nuevo marcador en la posición seleccionada
                    Marker marker = mMap.addMarker(new MarkerOptions().position(latLng));
                    markers.add(marker);

                    Log.d(TAG, "onMapClick: Marcador añadido en " + latLng);

                    // Cerrar el rectángulo si ya hay 4 marcadores
                    if (markers.size() == 4) {
                        cerrarRectangulo();
                    }
                } else {
                    // Mostrar un mensaje si ya se han colocado 4 marcadores
                    Toast.makeText(this, "Ya has colocado los 4 marcadores", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Notificar al usuario que el mapa y las áreas guardadas han sido eliminados
        Toast.makeText(this, "Mapa y áreas guardadas eliminados.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Método `centrarEnUbicacionActual`: Centra el mapa en la ubicación actual del usuario.
     *
     * Este método solicita los permisos de ubicación si no están otorgados, habilita la funcionalidad
     * de ubicación en el mapa y obtiene la última ubicación conocida del dispositivo. Luego, centra
     * la cámara del mapa en la ubicación obtenida.
     */
    private void centrarEnUbicacionActual() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Solicitar permiso de ubicación si no está otorgado
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        // Habilitar la funcionalidad de ubicación en el mapa
        mMap.setMyLocationEnabled(true);

        // Obtener la última ubicación conocida
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        LatLng ubicacionActual = new LatLng(location.getLatitude(), location.getLongitude());
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(ubicacionActual, 15));
                    } else {
                        Toast.makeText(this, "No se pudo obtener la ubicación actual.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Método `calcularPerimetro`: Calcula el perímetro de un polígono en el mapa.
     *
     * Este método verifica si hay un polígono dibujado en el mapa y, si es así, calcula el perímetro
     * sumando las distancias entre los vértices consecutivos del polígono.
     */
    private void calcularPerimetro() {
        if (polygon == null) {
            Toast.makeText(this, "Por favor, marca un área primero", Toast.LENGTH_SHORT).show();
            return;
        }

        double perimetro = 0;
        List<LatLng> puntos = polygon.getPoints();

        // Calcular la distancia entre cada par de puntos consecutivos
        for (int i = 0; i < puntos.size() - 1; i++) {
            perimetro += calcularDistancia(puntos.get(i), puntos.get(i + 1));
        }
        // Cerrar el polígono sumando la distancia entre el último punto y el primero
        perimetro += calcularDistancia(puntos.get(puntos.size() - 1), puntos.get(0));

        Toast.makeText(this, "Perímetro: " + perimetro + " metros", Toast.LENGTH_SHORT).show();
    }

    /**
     * Método `calcularDistancia`: Calcula la distancia entre dos puntos en coordenadas geográficas.
     *
     * Este método utiliza la fórmula del haversine para calcular la distancia en metros entre
     * dos puntos dados sus latitudes y longitudes.
     *
     * @param punto1 Primer punto (LatLng).
     * @param punto2 Segundo punto (LatLng).
     * @return Distancia en metros entre los dos puntos.
     */
    private double calcularDistancia(LatLng punto1, LatLng punto2) {
        double radioTierra = 6371000; // Radio de la Tierra en metros
        double dLat = Math.toRadians(punto2.latitude - punto1.latitude);
        double dLng = Math.toRadians(punto2.longitude - punto1.longitude);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(punto1.latitude)) * Math.cos(Math.toRadians(punto2.latitude)) *
                        Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return radioTierra * c;
    }

    /**
     * Método `descargarAreaSeleccionada`: Descarga datos del área seleccionada en el mapa.
     *
     * Este método verifica si se han colocado 4 marcadores en el mapa formando un área rectangular.
     * Si es así, utiliza la API de Overpass para descargar datos del área y los guarda en la base
     * de datos SQLite.
     */
    private void descargarAreaSeleccionada() {
        if (markers.size() == 4) {
            Log.d(TAG, "descargarAreaSeleccionada: Iniciando la descarga del área seleccionada");

            // Obtener las coordenadas mínimas y máximas del área
            LatLng punto1 = markers.get(0).getPosition();
            LatLng punto3 = markers.get(2).getPosition();
            double latMin = Math.min(punto1.latitude, punto3.latitude);
            double latMax = Math.max(punto1.latitude, punto3.latitude);
            double lngMin = Math.min(punto1.longitude, punto3.longitude);
            double lngMax = Math.max(punto1.longitude, punto3.longitude);

            Log.d(TAG, "descargarAreaSeleccionada: Coordenadas descargadas -> latMin: " + latMin +
                    ", lngMin: " + lngMin + ", latMax: " + latMax + ", lngMax: " + lngMax);

            // URL de la API de Overpass
            String url = "https://overpass-api.de/api/interpreter?data=[out:json];(node("
                    + latMin + "," + lngMin + "," + latMax + "," + lngMax + ");<;);out meta;";

            // Realizar la solicitud HTTP para descargar los datos del área
            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    response -> {
                        Log.d(TAG, "descargarAreaSeleccionada: Respuesta recibida, guardando en SQLite");

                        // Guardar los datos descargados en SQLite
                        DatabaseManager dbManager = new DatabaseManager(this);
                        dbManager.guardarArea("Área Seleccionada", latMin, lngMin, latMax, lngMax, response);
                        Toast.makeText(this, "Datos del área guardados en SQLite", Toast.LENGTH_SHORT).show();
                    },
                    error -> Log.e(TAG, "descargarAreaSeleccionada: Error al descargar datos del área", error));

            queue.add(stringRequest);
        } else {
            Toast.makeText(this, "Por favor, marca un área rectangular primero.", Toast.LENGTH_SHORT).show();
        }
    }}