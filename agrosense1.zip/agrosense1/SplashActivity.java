/**
 * SplashActivity
 *
 * Actividad que muestra una pantalla de carga (splash screen) al iniciar la aplicación.
 * Comprueba si hay un usuario autenticado en Firebase Authentication y verifica la
 * integridad de la base de datos local. Después de un breve retraso, redirige al usuario
 * según su estado de autenticación.
 */

package com.example.agrosense1;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SplashActivity extends Activity {

    private static final String TAG = "SplashActivity"; // Tag para logs de depuración
    private static final int SPLASH_DELAY = 3000; // Tiempo de retraso en milisegundos (3 segundos)

    /**
     * Método que se ejecuta al crear la actividad.
     * Configura la pantalla de carga, verifica el estado de autenticación y la integridad
     * de la base de datos, y redirige al usuario después de un retraso.
     *
     * @param savedInstanceState Estado previamente guardado de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash); // Establece el diseño de la pantalla de carga

        Log.d(TAG, "Iniciando Splash Screen");

        // Verifica si hay un usuario autenticado en Firebase Authentication
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance(); // Obtiene una instancia de FirebaseAuth
        FirebaseUser currentUser = firebaseAuth.getCurrentUser(); // Obtiene al usuario actualmente autenticado, si existe

        // Inicializa el administrador de la base de datos local
        DatabaseManager dbManager = new DatabaseManager(this);

        // Obtiene una instancia de la base de datos en modo escritura
        SQLiteDatabase db = dbManager.getWritableDatabase();

        crearTablasSiNoExisten(db, dbManager);

        // Inserta un registro de medición predeterminado si la tabla está vacía
        dbManager.insertRandomMedicionIfEmpty();

        //copyPdfFromRawToExternal();

        // Configura un retraso de 3 segundos antes de proceder
        new Handler().postDelayed(() -> {
            if (currentUser != null) {
                // Si hay un usuario autenticado, redirige a la pantalla principal
                Log.d(TAG, "Usuario autenticado: " + currentUser.getEmail());
                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
            } else {
                // Si no hay usuario autenticado, redirige a la pantalla de inicio de sesión
                Log.d(TAG, "No hay usuario autenticado");
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }

            // Finaliza la actividad de la pantalla de carga
            finish();
        }, SPLASH_DELAY);
    }

    /**
     * Copia un archivo PDF desde la carpeta 'res/raw' hacia un directorio
     * específico en el almacenamiento externo privado de la app.
     * Crea el directorio si no existe y evita copiar si el archivo ya existe.
     */
    void copyPdfFromRawToExternal() {
        // Obtener la ruta privada de almacenamiento externo para la app,
        // dentro de esta crea la carpeta 'media/agrosense'
        File targetDir = new File(getExternalFilesDir(null), "media/agrosense");

        // Si el directorio no existe, intenta crearlo (incluye padres)
        if (!targetDir.exists()) {
            boolean success = targetDir.mkdirs();  // Crear carpetas
            if (!success) {
                // Si falla la creación del directorio, se registra un error y se sale
                Log.e("CopyPDF", "No se pudo crear el directorio: " + targetDir.getAbsolutePath());
                return; // Termina la función si no se pudo crear la carpeta
            }
        }

        // Definir el archivo destino dentro del directorio anterior
        File targetFile = new File(targetDir, "reporte_agrosense.pdf");

        // Si el archivo ya existe, no se copia para evitar sobrescribir
        if (targetFile.exists()) return;

        // Abrir flujo de lectura para el archivo PDF empaquetado en res/raw
        try (InputStream in = getResources().openRawResource(R.raw.reporte_agrosense);
             // Abrir flujo de escritura para crear el archivo en la ruta destino
             OutputStream out = new FileOutputStream(targetFile)) {

            // Buffer temporal para lectura/escritura de bloques de bytes
            byte[] buffer = new byte[1024];
            int length;

            // Leer bloques de bytes del archivo original y escribirlos en destino
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }

            // Log para indicar que la copia fue exitosa
            Log.i("CopyPDF", "Archivo PDF copiado exitosamente en: " + targetFile.getAbsolutePath());

        } catch (IOException e) {
            // En caso de error, imprimir la pila de excepciones y registrar error
            e.printStackTrace();
            Log.e("CopyPDF", "Error al copiar archivo PDF: " + e.getMessage());
        }
    }

    /**
     * Verifica y crea todas las tablas necesarias si no existen.
     *
     * @param db Instancia SQLiteDatabase para ejecutar sentencias.
     * @param dbManager Instancia de DatabaseManager para acceder a las sentencias de creación.
     */
    private void crearTablasSiNoExisten(SQLiteDatabase db, DatabaseManager dbManager) {
        String[] tablas = {
                "plantas",
                "usuario",
                "mediciones",
                "clima",
                "areas"
        };

        for (String tabla : tablas) {
            if (!dbManager.checkTableExists(db, tabla)) {
                Log.d(TAG, "La tabla '" + tabla + "' no existe. Creándola...");
                String createSQL = obtenerSentenciaCreateTabla(dbManager, tabla);
                if (createSQL != null) {
                    db.execSQL(createSQL);
                    Log.d(TAG, "Tabla '" + tabla + "' creada correctamente.");
                } else {
                    Log.e(TAG, "No se encontró la sentencia CREATE para la tabla '" + tabla + "'");
                }
            } else {
                Log.d(TAG, "La tabla '" + tabla + "' ya existe.");
            }
        }
    }

    private String obtenerSentenciaCreateTabla(DatabaseManager dbManager, String tabla) {
        switch (tabla) {
            case "plantas":
                return DatabaseManager.CREATE_TABLE_PLANTAS;
            case "usuario":
                return DatabaseManager.CREATE_TABLE_USUARIO;
            case "mediciones":
                return DatabaseManager.CREATE_TABLE_MEDICIONES;
            case "clima":
                return DatabaseManager.CREATE_TABLE_CLIMA;
            case "areas":
                return DatabaseManager.CREATE_TABLE_AREAS;
            default:
                return null;
        }
    }
}