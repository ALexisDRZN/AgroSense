/**
 * RegisterActivity
 *
 * Esta actividad permite a los usuarios registrarse en la aplicación mediante un formulario.
 * Se valida la entrada del usuario, se registra la cuenta en Firebase Authentication
 * y se guarda la información del usuario en la base de datos local.
 */

package com.example.agrosense1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.ByteArrayOutputStream;

public class RegisterActivity extends Activity {

    private static final String TAG = "RegisterActivity"; // Tag para logs de depuración
    private FirebaseAuth firebaseAuth; // Instancia de FirebaseAuth para gestionar autenticación
    private EditText etEmail, etPassword, etConfirmPassword, etNombre, etApellidos; // Campos de entrada para el registro
    private TextView tvErrorMessage; // Texto para mostrar mensajes de error
    private DatabaseManager databaseManager; // Administrador de la base de datos local

    /**
     * Método que se ejecuta al crear la actividad.
     * Inicializa FirebaseAuth, DatabaseManager y las referencias a los elementos del layout.
     * También configura el botón de registro para manejar el evento de clic.
     *
     * @param savedInstanceState Estado previamente guardado de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance();

        // Inicializar DatabaseManager
        databaseManager = new DatabaseManager(this);

        // Referencias a los elementos del layout
        etEmail = findViewById(R.id.etEmail); // Campo para el correo electrónico
        etPassword = findViewById(R.id.etPassword); // Campo para la contraseña
        etConfirmPassword = findViewById(R.id.etConfirmPassword); // Campo para confirmar la contraseña
        etNombre = findViewById(R.id.Nombre); // Campo para el nombre del usuario
        etApellidos = findViewById(R.id.Apellidos); // Campo para los apellidos del usuario
        tvErrorMessage = findViewById(R.id.tvErrorMessage); // Texto para mostrar errores
        Button btnRegister = findViewById(R.id.btnRegister); // Botón para registrar al usuario

        // Configuración del evento de clic en el botón de registro
        btnRegister.setOnClickListener(v -> registerUser());
    }

    /**
     * Maneja el registro del usuario.
     * Valida la entrada del usuario, registra la cuenta en Firebase y guarda la información en la base de datos local.
     */
    private void registerUser() {
        // Obtener los datos introducidos por el usuario
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String nombre = etNombre.getText().toString().trim();
        String apellidos = etApellidos.getText().toString().trim();

        // Validar que todos los campos están completos
        if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || nombre.isEmpty() || apellidos.isEmpty()) {
            tvErrorMessage.setText("Por favor, completa todos los campos.");
            tvErrorMessage.setVisibility(View.VISIBLE);
            return;
        }

        // Validar que las contraseñas coinciden
        if (!password.equals(confirmPassword)) {
            tvErrorMessage.setText("Las contraseñas no coinciden.");
            tvErrorMessage.setVisibility(View.VISIBLE);
            return;
        }

        // Validar que la contraseña tiene al menos 6 caracteres
        if (password.length() < 6) {
            tvErrorMessage.setText("La contraseña debe tener al menos 6 caracteres.");
            tvErrorMessage.setVisibility(View.VISIBLE);
            return;
        }

        // Registrar al usuario en Firebase Authentication
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Registro exitoso
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        Log.d(TAG, "Registro exitoso: " + user.getEmail());
                        Toast.makeText(this, "Cuenta creada exitosamente", Toast.LENGTH_SHORT).show();

                        // Guardar los datos del usuario en la base de datos local
                        saveUserToDatabase(nombre, apellidos, email);

                        // Redirigir al formulario de inicio de sesión
                        startActivity(new Intent(RegisterActivity.this, LoginFormActivity.class));
                        finish(); // Finaliza esta actividad para evitar volver a ella
                    } else {
                        // Error en el registro
                        Log.w(TAG, "Error en el registro", task.getException());
                        tvErrorMessage.setText("Error: " + task.getException().getMessage());
                        tvErrorMessage.setVisibility(View.VISIBLE);
                    }
                });
    }

    /**
     * Guarda los datos del usuario en la base de datos local.
     * Incluye el nombre, apellidos, correo electrónico y una imagen predeterminada como foto de perfil.
     *
     * @param nombre    Nombre del usuario.
     * @param apellidos Apellidos del usuario.
     * @param correo    Correo electrónico del usuario.
     */
    private void saveUserToDatabase(String nombre, String apellidos, String correo) {
        // Crear una imagen predeterminada para el usuario
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.person); // Imagen predeterminada
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream); // Comprimir la imagen
        byte[] foto = byteArrayOutputStream.toByteArray(); // Convertir la imagen a un array de bytes

        // Insertar los datos del usuario en la base de datos local
        long id = databaseManager.addUsuario(nombre, apellidos, foto, correo,null);
        if (id == -1) {
            // Error al insertar en la base de datos
            Log.e(TAG, "Error al insertar el usuario en la base de datos");
        } else {
            // Usuario insertado exitosamente
            Log.d(TAG, "Usuario insertado en la base de datos con ID: " + id);
        }
    }
}