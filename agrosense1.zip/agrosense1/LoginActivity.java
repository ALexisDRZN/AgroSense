package com.example.agrosense1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * LoginActivity
 *
 * Clase que gestiona la pantalla de inicio de sesión de la aplicación. Proporciona botones
 * para iniciar sesión, registrar una cuenta nueva y recuperar la contraseña olvidada.
 */
public class LoginActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Referencias a los botones y elementos de la interfaz
        Button btnLogin = findViewById(R.id.btnLogin); // Botón para iniciar sesión
        Button btnRegister = findViewById(R.id.btnRegister); // Botón para registrar una cuenta
        TextView txtForgotPassword = findViewById(R.id.txtForgotPassword); // Texto para recuperar contraseña

        // Acción del botón "Iniciar Sesión"
        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, LoginFormActivity.class);
            startActivity(intent); // Navegar a la actividad de formulario de inicio de sesión
        });

        // Acción del botón "Crear Cuenta"
        btnRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent); // Navegar a la actividad de registro
        });

        // Acción del texto "¿Olvidaste tu contraseña?"
        txtForgotPassword.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
            startActivity(intent); // Navegar a la actividad de recuperación de contraseña
        });
    }
}