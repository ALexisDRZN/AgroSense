package com.example.agrosense1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PlantActivity extends AppCompatActivity {

    private RecyclerView plantRecyclerView;
    private PlantAdapter plantAdapter;
    private ArrayList<Planta> plantList;
    private DatabaseManager databaseManager;

    private DrawerLayout drawerLayout;
    private ImageButton btnMenu;
    private Button btnPerfil, btnPlantas, btnMapeo, btnHistorial, btnSalir, btnGrafica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plants);

        databaseManager = new DatabaseManager(this);

        // Referencias a los elementos del layout
        drawerLayout = findViewById(R.id.drawer_layout);
        btnMenu = findViewById(R.id.btnMenu);

        // Referencias a los botones del menú
        btnPerfil = findViewById(R.id.btnPerfil);
        btnPlantas = findViewById(R.id.btnPlantas);
        btnMapeo = findViewById(R.id.btnMapeo);
        btnGrafica = findViewById(R.id.btnGrafica);
        btnHistorial = findViewById(R.id.btnHistorial);
        btnSalir = findViewById(R.id.btnSalir);

        // Acción al hacer clic en el botón del menú
        btnMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(findViewById(R.id.menu_layout))) {
                drawerLayout.closeDrawer(findViewById(R.id.menu_layout));  // Cierra el menú
            } else {
                drawerLayout.openDrawer(findViewById(R.id.menu_layout));  // Abre el menú
            }
        });

        // Configuración de los botones para navegar a las actividades correspondientes
        btnPerfil.setOnClickListener(v -> {
            startActivity(new Intent(PlantActivity.this, PerfilActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnPlantas.setOnClickListener(v -> {
            startActivity(new Intent(PlantActivity.this, PlantActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnMapeo.setOnClickListener(v -> {
            startActivity(new Intent(PlantActivity.this, HomeActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnGrafica.setOnClickListener(v -> {
            startActivity(new Intent(PlantActivity.this, GraficaActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnHistorial.setOnClickListener(v -> {
            startActivity(new Intent(PlantActivity.this, HistorialActivity.class));
            drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
        });

        btnSalir.setOnClickListener(v -> {
            finishAffinity();
        });

        // Inicializar las vistas
        plantRecyclerView = findViewById(R.id.plantRecyclerView);
        plantList = new ArrayList<>();
        plantAdapter = new PlantAdapter(plantList, databaseManager, this::loadPlantasFromSQLite);

        // Establecer el LayoutManager
        plantRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Asignar el adaptador al RecyclerView
        plantRecyclerView.setAdapter(plantAdapter);

        // Sincronizar desde Firebase y cargar desde SQLite
        syncPlantasFromFirebase();
        loadPlantasFromSQLite();
    }

    private void syncPlantasFromFirebase() {
        DatabaseReference databaseReference =
                FirebaseDatabase.getInstance().getReference();
        Log.d("PlantActivity", "Conectando a Firebase...");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Planta planta = snapshot.getValue(Planta.class);
                        if (planta != null) {
                            Log.d("PlantActivity", "Procesando planta: " + planta.nombre);
                            databaseManager.addOrUpdatePlanta(planta.nombre, Float.parseFloat(planta.nitrogeno),
                                    Float.parseFloat(planta.fosforo), Float.parseFloat(planta.potasio));
                        } else {
                            Log.w("PlantActivity", "Planta nula encontrada");
                        }
                    }
                    loadPlantasFromSQLite(); // Recarga los datos en la interfaz
                } else {
                    Log.w("PlantActivity", "No se encontraron datos en la referencia");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("PlantActivity", "Error al leer datos de Firebase", databaseError.toException());
            }
        });
    }

    private void loadPlantasFromSQLite() {
        Log.d("PlantActivity", "Cargando plantas desde SQLite...");
        plantList.clear();

        Cursor cursor = databaseManager.getAllPlantas();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String nombre = cursor.getString(cursor.getColumnIndex("nombre"));
                float nitrogeno = cursor.getFloat(cursor.getColumnIndex("nitrogeno"));
                float fosforo = cursor.getFloat(cursor.getColumnIndex("fosforo"));
                float potasio = cursor.getFloat(cursor.getColumnIndex("potasio"));
                boolean cargado = cursor.getInt(cursor.getColumnIndex("cargado")) == 1;

                Log.d("PlantActivity", "Planta cargada de SQLite: " +
                        "Nombre=" + nombre +
                        ", N=" + nitrogeno +
                        ", P=" + fosforo +
                        ", K=" + potasio +
                        ", Cargado=" + cargado);

                plantList.add(new Planta(nombre, String.valueOf(fosforo), String.valueOf(potasio), String.valueOf(nitrogeno), cargado));
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Log.w("PlantActivity", "No se encontraron plantas en SQLite");
        }
        plantAdapter.notifyDataSetChanged();
    }

    public static class Planta {
        public String nombre, fosforo, potasio, nitrogeno;
        public boolean cargado;

        // Constructor sin argumentos (necesario para Firebase)
        public Planta() {}

        public Planta(String nombre, String fosforo, String potasio, String nitrogeno, boolean cargado) {
            this.nombre = nombre;
            this.fosforo = fosforo;
            this.potasio = potasio;
            this.nitrogeno = nitrogeno;
            this.cargado = cargado;
        }
    }
}