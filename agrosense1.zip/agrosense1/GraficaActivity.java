/**
 * GraficaActivity
 *
 * Clase que maneja la actividad de gráficas en la aplicación AgroSense.
 * Esta actividad incluye:
 * - Visualización de datos climáticos utilizando coordenadas GPS.
 * - Actualización de gráficas con datos obtenidos del dispositivo ESP32.
 * - Navegación entre diferentes pantallas de la aplicación usando un menú lateral.
 */

package com.example.agrosense1;

// Importaciones necesarias para la funcionalidad de la actividad
import android.Manifest; // Permiso para acceder a la ubicación del dispositivo.
import android.content.Intent; // Permite la navegación entre actividades.
import android.content.pm.PackageManager; // Gestiona permisos otorgados por el usuario.
import android.database.Cursor; // Representa los resultados de consultas a la base de datos.
import android.location.Location; // Representa la ubicación geográfica del dispositivo.
import android.os.Bundle; // Contiene datos de estado de la actividad.
import android.util.Log; // Permite registrar mensajes para depuración.
import android.widget.Button; // Botón interactivo en la interfaz de usuario.
import android.widget.ImageButton; // Botón con ícono en la interfaz de usuario.
import android.widget.ImageView; // Imagen que se muestra en la interfaz de usuario.
import android.widget.TextView; // Elemento de texto para mostrar información en la interfaz.
import android.widget.Toast; // Mensajes emergentes breves para el usuario.

// Importaciones de AndroidX
import androidx.annotation.NonNull; // Anotación para especificar que un valor no puede ser nulo.
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity; // Clase base para actividades con soporte AppCompat.
import androidx.core.app.ActivityCompat; // Clase para manejar permisos en tiempo de ejecución.
import androidx.drawerlayout.widget.DrawerLayout; // Diseño para manejar un menú lateral (drawer).

// Librerías para visualización de gráficos
import com.github.mikephil.charting.charts.LineChart; // Componente para gráficos de líneas.

// Servicios de ubicación de Google
import com.google.android.gms.location.FusedLocationProviderClient; // Cliente para acceder a la ubicación del dispositivo.
import com.google.android.gms.location.LocationServices; // Servicios de ubicación proporcionados por Google.
import com.google.android.gms.tasks.OnSuccessListener; // Escucha para manejar operaciones exitosas.

// Librerías para manejo de JSON
import org.json.JSONObject; // Clase para manejar datos en formato JSON.

// Librerías para manejo de red
import java.io.InputStreamReader; // Lector de datos desde flujos de entrada.
import java.net.HttpURLConnection; // Clase para manejar conexiones HTTP.
import java.net.URL; // Representación de URLs.

// Librerías para manejo de fechas
import java.text.SimpleDateFormat; // Clase para formatear fechas.
import java.util.Date; // Representación de la fecha actual.

public class GraficaActivity extends AppCompatActivity {

    // Componentes del menú lateral
    private DrawerLayout drawerLayout; // Layout para el menú lateral.
    private ImageButton btnMenu; // Botón para abrir/cerrar el menú lateral.
    private Button btnPerfil, btnPlantas, btnMapeo, btnHistorial, btnSalir, btnGrafica; // Botones del menú.

    // Referencias a los componentes de la interfaz de usuario
    private LineChart lineChart; // Gráfica de línea para mostrar datos.
    private GraficasManager graficasManager; // Administrador de gráficos.
    private WeatherManager weatherManager; // Administrador del clima.
    private TextView tvTemperatura, tvDescripcion, tvHumedad, tvViento; // Elementos para mostrar datos climáticos.
    private ImageView ivClimaIcono; // Icono para mostrar el estado del clima.

    // Variables para la ubicación
    private FusedLocationProviderClient fusedLocationProviderClient; // Cliente para obtener la ubicación actual.
    private double latitud = 19.4326; // Latitud predeterminada (Ciudad de México).
    private double longitud = -99.1332; // Longitud predeterminada (Ciudad de México).

    /**
     * Método que se ejecuta al crear la actividad.
     *
     * Inicializa los componentes de la interfaz de usuario, configura el menú lateral y obtiene
     * la ubicación actual para actualizar los datos climáticos.
     *
     * @param savedInstanceState Estado guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafica);

        // Inicialización del cliente de ubicación y obtención de la ubicación actual.
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        obtenerUbicacionActual();

        // Vinculación de componentes de la interfaz con sus IDs.
        Button btnActualizar = findViewById(R.id.btnActualizar);
        drawerLayout = findViewById(R.id.drawer_layout);
        btnMenu = findViewById(R.id.btnMenu);
        btnPerfil = findViewById(R.id.btnPerfil);

        btnPlantas = findViewById(R.id.btnPlantas);
        btnMapeo = findViewById(R.id.btnMapeo);
        btnGrafica = findViewById(R.id.btnGrafica);
        btnHistorial = findViewById(R.id.btnHistorial);
        btnSalir = findViewById(R.id.btnSalir);
        tvTemperatura = findViewById(R.id.tvTemperatura);
        tvDescripcion = findViewById(R.id.tvDescripcion);
        tvHumedad = findViewById(R.id.tvHumedad);
        tvViento = findViewById(R.id.tvViento);
        ivClimaIcono = findViewById(R.id.ivClimaIcono);

        // Inicialización de WeatherManager y actualización del clima.
        weatherManager = new WeatherManager(this, tvTemperatura, tvDescripcion, tvHumedad, tvViento, ivClimaIcono);
        weatherManager.actualizarClima(latitud, longitud);

        // Inicialización de GraficasManager y configuración de la gráfica.
        lineChart = findViewById(R.id.lineChart);
        DatabaseManager dbManager = new DatabaseManager(this);
        graficasManager = new GraficasManager(lineChart, dbManager, this);
        graficasManager.actualizarGrafica();

        // Configuración del botón "Actualizar".
        btnActualizar.setOnClickListener(v -> sendRequestToESP32());

        // Configuración del botón del menú.
        btnMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(findViewById(R.id.menu_layout))) {
                drawerLayout.closeDrawer(findViewById(R.id.menu_layout));
            } else {
                drawerLayout.openDrawer(findViewById(R.id.menu_layout));
            }
        });

        // Configuración de los botones del menú.
        btnPerfil.setOnClickListener(v -> navigateToActivity(PerfilActivity.class));
        btnPlantas.setOnClickListener(v -> navigateToActivity(PlantActivity.class));
        btnMapeo.setOnClickListener(v -> navigateToActivity(HomeActivity.class));
        btnGrafica.setOnClickListener(v -> navigateToActivity(GraficaActivity.class));
        btnHistorial.setOnClickListener(v -> navigateToActivity(HistorialActivity.class));
        btnSalir.setOnClickListener(v -> finishAffinity()); // Cierra la aplicación.
    }

    /**
     * Navega a la actividad especificada y cierra el menú lateral.
     *
     * @param targetActivity Clase de la actividad a la que se desea navegar.
     */
    private void navigateToActivity(Class<?> targetActivity) {
        startActivity(new Intent(GraficaActivity.this, targetActivity));
        drawerLayout.closeDrawer(findViewById(R.id.menu_layout)); // Cierra el menú lateral.
    }

    /**
     * Obtiene la ubicación actual del dispositivo.
     *
     * Requiere permisos de ubicación. Si no se tienen, solicita al usuario que los otorgue.
     * Una vez obtenida la ubicación, actualiza los datos climáticos.
     */
    private void obtenerUbicacionActual() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        latitud = location.getLatitude();
                        longitud = location.getLongitude();
                        Log.d("GraficaActivity", "Ubicación obtenida: Latitud = " + latitud + ", Longitud = " + longitud);

                        // Actualizar el clima con las coordenadas obtenidas.
                        weatherManager.actualizarClima(latitud, longitud);
                    } else {
                        Log.d("GraficaActivity", "No se pudo obtener la ubicación actual.");
                        Toast.makeText(this, "No se pudo obtener la ubicación actual.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Envía una solicitud al ESP32 y maneja la respuesta.
     */
    private void sendRequestToESP32() {
        new Thread(() -> {
            try {
                URL url = new URL("http://192.168.4.1"); // Dirección IP del ESP32.
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setConnectTimeout(5000);
                urlConnection.setReadTimeout(5000);

                InputStreamReader reader = new InputStreamReader(urlConnection.getInputStream());
                StringBuilder response = new StringBuilder();
                int data = reader.read();
                while (data != -1) {
                    response.append((char) data);
                    data = reader.read();
                }
                reader.close();

                JSONObject jsonResponse = new JSONObject(response.toString());
                runOnUiThread(() -> {
                    Toast.makeText(GraficaActivity.this, "Datos recibidos: " + jsonResponse, Toast.LENGTH_LONG).show();
                    // Guardar datos en SQLite
                    saveDataToSQLite(jsonResponse.toString());
                    // Verificar alertas basadas en los datos recibidos
                    verificarAlertas(jsonResponse);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(GraficaActivity.this, "Error al obtener datos: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * Guarda los datos recibidos del ESP32 en la base de datos SQLite.
     *
     * @param data Cadena en formato JSON con los datos recibidos.
     */
    private void saveDataToSQLite(String data) {
        DatabaseManager dbManager = new DatabaseManager(GraficaActivity.this);
        try {
            JSONObject jsonObject = new JSONObject(data);
            float humedad = (float) jsonObject.getDouble("humedad");
            float conductividad = (float) jsonObject.getDouble("conductividad");
            float ph = (float) jsonObject.getDouble("ph");
            float nitrogeno = (float) jsonObject.getDouble("nitrogeno");
            float fosforo = (float) jsonObject.getDouble("fosforo");
            float potasio = (float) jsonObject.getDouble("potasio");

            String fechaHora = getCurrentDateTime();
            String planta = getPlantaSeleccionada(dbManager);

            dbManager.addMedicion(humedad, conductividad, ph, nitrogeno, fosforo, potasio, fechaHora, planta);
            Toast.makeText(this, "Datos guardados en la base de datos", Toast.LENGTH_SHORT).show();

            graficasManager.actualizarGrafica();


        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar los datos: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Obtiene el nombre de la planta que está marcada como activa.
     *
     * @param dbManager Instancia del administrador de la base de datos.
     * @return Nombre de la planta activa o un valor predeterminado si no hay ninguna activa.
     */
    private String getPlantaSeleccionada(DatabaseManager dbManager) {
        Cursor cursor = dbManager.getReadableDatabase().rawQuery(
                "SELECT nombre FROM plantas WHERE cargado = 1", null);
        String planta = "Planta"; // Valor predeterminado.

        if (cursor != null && cursor.moveToFirst()) {
            planta = cursor.getString(cursor.getColumnIndex("nombre"));
        }
        if (cursor != null) {
            cursor.close();
        }
        return planta;
    }

    /**
     * Obtiene la fecha actual en formato "yyyy-MM-dd".
     *
     * @return Cadena con la fecha actual.
     */
    public String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date now = new Date();
        return sdf.format(now);
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        new AlertDialog.Builder(this)
                .setTitle(titulo) // Título del cuadro de diálogo
                .setMessage(mensaje) // Mensaje descriptivo
                .setPositiveButton("Entendido", (dialog, which) -> {
                    // Acción al presionar "Entendido" (puede dejarse vacío si no hay lógica adicional)
                    dialog.dismiss(); // Cierra el cuadro de diálogo
                })
                .show(); // Muestra el cuadro de diálogo
    }

    /**
     * Verifica los niveles de nutrientes (nitrógeno, fósforo y potasio) contra los límites
     * definidos en la base de datos y muestra alertas basadas en los rangos establecidos:
     * - Dentro del rango (±5 unidades): Todo está bien.
     * - Más de 5 unidades por debajo o por encima: Nivel bajo/alto.
     * - Más de 10 unidades por debajo o por encima: Nivel crítico.
     *
     * @param jsonResponse Objeto JSON con los datos de nutrientes recibidos.
     */
    private void verificarAlertas(JSONObject jsonResponse) {
        try {
            DatabaseManager dbManager = new DatabaseManager(this);

            // Obtener datos del JSON
            float nitrogeno = (float) jsonResponse.getDouble("nitrogeno");
            float fosforo = (float) jsonResponse.getDouble("fosforo");
            float potasio = (float) jsonResponse.getDouble("potasio");

            // Obtener límites de la planta seleccionada
            Cursor cursor = dbManager.getReadableDatabase().rawQuery("SELECT * FROM plantas WHERE cargado = 1", null);
            if (cursor != null && cursor.moveToFirst()) {
                float limiteNitrogeno = cursor.getFloat(cursor.getColumnIndex("nitrogeno"));
                float limiteFosforo = cursor.getFloat(cursor.getColumnIndex("fosforo"));
                float limitePotasio = cursor.getFloat(cursor.getColumnIndex("potasio"));

                // Verificar niveles de nitrógeno
                verificarNivel("Nitrógeno", nitrogeno, limiteNitrogeno);

                // Verificar niveles de fósforo
                verificarNivel("Fósforo", fosforo, limiteFosforo);

                // Verificar niveles de potasio
                verificarNivel("Potasio", potasio, limitePotasio);

                cursor.close();
            }
        } catch (Exception e) {
            mostrarAlerta("Error", "Error al verificar alertas: " + e.getMessage());
        }
    }

    /**
     * Verifica el nivel de un nutriente específico contra un límite y muestra alertas
     * basadas en los rangos establecidos.
     *
     * @param nutriente Nombre del nutriente (e.g., "Nitrógeno", "Fósforo", "Potasio").
     * @param valor     Valor actual del nutriente medido.
     * @param limite    Límite estático del nutriente definido en la base de datos.
     */
    private void verificarNivel(String nutriente, float valor, float limite) {
        float diferencia = Math.abs(valor - limite); // Diferencia absoluta entre el valor y el límite

        if (diferencia <= 5) {
            // Dentro del rango aceptable (±5 unidades)
            mostrarAlerta("Estado del " + nutriente, "El nivel de " + nutriente + " está dentro del rango aceptable.");
        } else if (diferencia > 5 && diferencia <= 10) {
            // Más de 5 unidades por encima o por debajo
            String mensaje = valor > limite
                    ? "El nivel de " + nutriente + " es alto. Mantente alerta."
                    : "El nivel de " + nutriente + " es bajo. Mantente alerta.";
            mostrarAlerta("Alerta de " + nutriente, mensaje);
        } else {
            // Más de 10 unidades por encima o por debajo
            String mensaje = valor > limite
                    ? "El nivel de " + nutriente + " es críticamente alto. Requiere atención inmediata."
                    : "El nivel de " + nutriente + " es críticamente bajo. Requiere atención inmediata.";
            mostrarAlerta("Alerta Crítica de " + nutriente, mensaje);
        }
    }
}