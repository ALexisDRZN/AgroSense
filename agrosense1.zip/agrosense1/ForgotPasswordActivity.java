/**
 * ForgotPasswordActivity
 *
 * Actividad que permite a los usuarios recuperar su contraseña enviando un correo electrónico
 * a través de Firebase Authentication. Proporciona una interfaz de usuario para que el usuario
 * ingrese su correo electrónico y reciba el enlace de recuperación de contraseña.
 */

package com.example.agrosense1;

// Importación de clases de Android
import android.app.Activity; // Clase base para actividades simples que no utilizan ActionBar ni AppCompat.
import android.os.Bundle; // Clase para pasar datos entre actividades y restaurar estados.
import android.view.View; // Clase para manejar y definir vistas.
import android.widget.Button; // Clase para representar y manipular botones.
import android.widget.EditText; // Clase para representar y manipular campos de texto de entrada.
import android.widget.TextView; // Clase para representar y manipular texto en pantalla.
import android.widget.Toast; // Clase para mostrar mensajes emergentes breves al usuario.

// Importación de Firebase Authentication
import com.google.firebase.auth.FirebaseAuth; // Clase principal para manejar la autenticación de usuarios con Firebase.

public class ForgotPasswordActivity extends Activity {

    // Instancia de FirebaseAuth para interactuar con Firebase Authentication.
    private FirebaseAuth firebaseAuth;

    // Elementos de la interfaz de usuario.
    private EditText etEmail; // Campo de entrada para que el usuario ingrese su correo electrónico.
    private TextView tvErrorMessage; // TextView para mostrar mensajes de error.

    /**
     * Método que se ejecuta al crear la actividad.
     *
     * Configura la interfaz de usuario y los elementos necesarios para la funcionalidad
     * de recuperación de contraseña.
     *
     * @param savedInstanceState Estado guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password); // Asigna el diseño de la actividad.

        // Inicializa Firebase Authentication.
        firebaseAuth = FirebaseAuth.getInstance();

        // Vincula los elementos de la interfaz de usuario con sus IDs en el diseño.
        etEmail = findViewById(R.id.etEmail); // Campo de entrada de correo electrónico.
        tvErrorMessage = findViewById(R.id.tvErrorMessage); // TextView para mostrar errores.
        Button btnSendRecoveryEmail = findViewById(R.id.btnSendRecoveryEmail); // Botón para enviar correo de recuperación.

        // Configura el evento de clic para el botón de envío.
        btnSendRecoveryEmail.setOnClickListener(v -> sendRecoveryEmail());
    }

    /**
     * Envía un correo de recuperación de contraseña a través de Firebase.
     *
     * Este método verifica que el campo de correo electrónico no esté vacío.
     * Si el correo es válido, se envía una solicitud a Firebase para enviar un correo de
     * recuperación de contraseña al usuario. Muestra mensajes de éxito o error según el resultado.
     */
    private void sendRecoveryEmail() {
        // Obtiene el correo electrónico ingresado por el usuario.
        String email = etEmail.getText().toString().trim();

        // Verifica si el campo de correo electrónico está vacío.
        if (email.isEmpty()) {
            tvErrorMessage.setText("Por favor, ingresa tu correo electrónico."); // Mensaje de error.
            tvErrorMessage.setVisibility(View.VISIBLE); // Muestra el mensaje de error.
            return;
        }

        // Envía el correo de recuperación mediante Firebase Authentication.
        firebaseAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Muestra un mensaje de éxito y cierra la actividad.
                        Toast.makeText(this, "Correo de recuperación enviado.", Toast.LENGTH_SHORT).show();
                        finish(); // Regresa a la pantalla anterior.
                    } else {
                        // Muestra un mensaje de error en caso de fallo.
                        tvErrorMessage.setText("Error: " + task.getException().getMessage());
                        tvErrorMessage.setVisibility(View.VISIBLE);
                    }
                });
    }
}