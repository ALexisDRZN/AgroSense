/**
 * LoginFormActivity
 *
 * Actividad que gestiona el inicio de sesión en la aplicación AgroSense.
 * Permite autenticar usuarios con email/contraseña o mediante Google Sign-In.
 * También guarda los datos del usuario en la base de datos local.
 */

package com.example.agrosense1;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import java.io.ByteArrayOutputStream;

public class LoginFormActivity extends Activity {

    private static final String TAG = "LoginFormActivity";
    private static final int RC_SIGN_IN = 100; // Código de solicitud para Google Sign-In
    private FirebaseAuth firebaseAuth;
    private GoogleSignInClient googleSignInClient;

    private EditText etEmail, etPassword;
    private TextView tvErrorMessage;

    /**
     * Método que se ejecuta al crear la actividad.
     * Configura los botones, inicializa Firebase y Google Sign-In.
     *
     * @param savedInstanceState Estado previamente guardado de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        firebaseAuth = FirebaseAuth.getInstance();

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        tvErrorMessage = findViewById(R.id.tvErrorMessage);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button googleButton = findViewById(R.id.Googlebutton);

        btnLogin.setOnClickListener(v -> loginUser());

        // Configuración de Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id)) // Se obtiene de google-services.json
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        // Inicia sesión con Google al presionar el botón
        googleButton.setOnClickListener(v -> signInWithGoogle());
    }

    /**
     * Inicia sesión en Firebase con email y contraseña.
     * Si las credenciales son correctas, redirige al usuario a la actividad principal.
     */
    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            tvErrorMessage.setText("Por favor, completa todos los campos.");
            tvErrorMessage.setVisibility(View.VISIBLE);
            return;
        }

        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        Log.d(TAG, "Inicio de sesión exitoso: " + user.getEmail());
                        Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginFormActivity.this, HomeActivity.class));
                        finish();
                    } else {
                        Log.w(TAG, "Error en inicio de sesión", task.getException());
                        tvErrorMessage.setText("Error: " + task.getException().getMessage());
                        tvErrorMessage.setVisibility(View.VISIBLE);
                    }
                });
    }

    /**
     * Inicia el flujo de inicio de sesión con Google.
     */
    private void signInWithGoogle() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    /**
     * Maneja los resultados de las actividades iniciadas desde esta actividad.
     *
     * @param requestCode Código de solicitud de la actividad iniciada.
     * @param resultCode Código de resultado devuelto por la actividad.
     * @param data Intent que contiene datos adicionales de la actividad.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(Exception.class);
                if (account != null) {
                    firebaseAuthWithGoogle(account);
                }
            } catch (Exception e) {
                Log.w(TAG, "Google sign in failed", e);
                Toast.makeText(this, "Inicio de sesión con Google fallido", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Autentica con Firebase usando el token de Google.
     *
     * @param account Cuenta de Google obtenida del flujo de inicio de sesión.
     */
    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        if (user != null) {
                            String name = user.getDisplayName() != null ? user.getDisplayName() : "User99999";
                            String email = user.getEmail();
                            String photoUrl = user.getPhotoUrl() != null ? user.getPhotoUrl().toString() : "";

                            Log.d("LoginFormActivity", "Nombre: " + name);
                            Log.d("LoginFormActivity", "Correo: " + email);
                            Log.d("LoginFormActivity", "Photo URL: " + photoUrl);

                            // Guardar los datos del usuario en la base de datos
                            DatabaseManager dbManager = new DatabaseManager(this);
                            saveUserToDatabase(name, email, photoUrl, dbManager);

                            // Redirige al perfil
                            Intent intent = new Intent(LoginFormActivity.this, HomeActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    } else {
                        Log.e("LoginFormActivity", "Error al autenticar con Firebase: " + task.getException().getMessage());
                        Toast.makeText(this, "Autenticación fallida", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Guarda los datos del usuario en la base de datos local.
     *
     * @param name Nombre del usuario.
     * @param email Correo electrónico del usuario.
     * @param photoUrl URL de la foto del usuario.
     * @param dbManager Instancia de DatabaseManager para guardar los datos.
     */
    private void saveUserToDatabase(String name, String email, String photoUrl, DatabaseManager dbManager) {
        if (photoUrl != null && !photoUrl.isEmpty()) {
            Glide.with(this)
                    .asBitmap()
                    .load(photoUrl)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                            try {
                                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                                resource.compress(Bitmap.CompressFormat.PNG, 100, stream);
                                byte[] photoBytes = stream.toByteArray();
                                Log.d("saveUserToDatabase", "Imagen descargada y convertida a byte[]. Tamaño: " + photoBytes.length);

                                // Verificar si ya existe usuario en la fila 1
                                Cursor cursor = dbManager.getUsuarios();
                                if (cursor != null && cursor.moveToFirst()) {
                                    // Actualizar usuario en la fila 1 (id=1)
                                    boolean actualizado = dbManager.actualizarUsuario(1, name, "N/A", photoBytes, email, null);
                                    Log.d("saveUserToDatabase", actualizado ? "Usuario actualizado correctamente." : "Error al actualizar usuario.");
                                } else {
                                    // Insertar nuevo usuario
                                    long result = dbManager.addUsuario(name, "N/A", photoBytes, email, null);
                                    Log.d("saveUserToDatabase", result != -1 ? "Usuario insertado correctamente." : "Error al insertar usuario.");
                                }
                                if(cursor != null) cursor.close();

                            } catch (Exception e) {
                                Log.e("saveUserToDatabase", "Error al procesar la imagen: " + e.getMessage());
                            }
                        }

                        @Override
                        public void onLoadCleared(Drawable placeholder) {
                        }
                    });
        } else {
            byte[] defaultPhoto = Utils.drawableToByteArray(this, R.drawable.person);
            Cursor cursor = dbManager.getUsuarios();
            if (cursor != null && cursor.moveToFirst()) {
                boolean actualizado = dbManager.actualizarUsuario(1, name, "N/A", defaultPhoto, email, null);
                Log.d("saveUserToDatabase", actualizado ? "Usuario actualizado correctamente." : "Error al actualizar usuario.");
            } else {
                long result = dbManager.addUsuario(name, "N/A", defaultPhoto, email, null);
                Log.d("saveUserToDatabase", result != -1 ? "Usuario insertado correctamente." : "Error al insertar usuario.");
            }
            if(cursor != null) cursor.close();
        }
    }

}